export const environment = {
  production: true,
  azimageUrl:'https://everdevuat.blob.core.windows.net/',
  environmentvariable:'test',
    // apiurl:'http://localhost:8080/api/',
// apiurl:'https://172.188.80.209:8443/api/',
apiurl:'https://everbackend.onrender.com/api/',
  azimageUrl_hub:'https://everdevuat.blob.core.windows.net/hubs/',
  azimageUrl_pic:'https://everdevuat.blob.core.windows.net/profilepic/',
};
