import { TimeampmPipe } from './timeampm.pipe';

describe('TimeampmPipe', () => {
  it('create an instance', () => {
    const pipe = new TimeampmPipe();
    expect(pipe).toBeTruthy();
  });
});
