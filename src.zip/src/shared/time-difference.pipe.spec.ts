import { TimeDifferencePipe } from './time-difference.pipe';

describe('TimeDifferencePipe', () => {
  it('create an instance', () => {
    const pipe = new TimeDifferencePipe();
    expect(pipe).toBeTruthy();
  });
});
